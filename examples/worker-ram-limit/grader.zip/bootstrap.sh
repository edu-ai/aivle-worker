#!/bin/bash
python grader.py
